<?php

session_start();
session_destroy();

  ?>


<br><br><h1>¡Haz salido de la aplicación!</h1>